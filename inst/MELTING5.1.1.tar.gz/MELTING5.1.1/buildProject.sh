#!/bin/bash

ant compile
ant jar
ant guijar
ant javadoc
